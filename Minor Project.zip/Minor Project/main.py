import cv2
from tracker import *

# Create tracker object
tracker = EuclideanDistTracker()

cap = cv2.VideoCapture("highway.mp4")

# Object detection from Stable camera
object_detector = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=40)  # also to detect shadows

while True:
    ret, frame = cap.read()
    if frame is None:
        break;
    height, width, _ = frame.shape

    # Extracting Region of interest
    roi = frame[340: 720,500: 800]

    # 1. Object Detection
    mask = object_detector.apply(roi)
    # If pixel intensity is greater than the set threshold,
    # value set to 255, else set to 0 (black).
    # To Focus on only Object not the shadows
    _, mask = cv2.threshold(mask, 254, 255, cv2.THRESH_BINARY)

# To find proper Coordinates from the mask
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    detections = [] # An empty array for the dimensions of the Rectangle
    for cnt in contours:
        # improve the extraction by removing all the smaller elements
        # and focus our attention on objects that are larger than a certain area.
        area = cv2.contourArea(cnt)
        if area > 100:
            #cv2.drawContours(roi, [cnt], -1, (0, 255, 0), 2)
            x, y, w, h = cv2.boundingRect(cnt) #Bounding Object with Rectangle


            detections.append([x, y, w, h])

    # 2. Object Tracking
    boxes_ids = tracker.update(detections)
    for box_id in boxes_ids:
        x, y, w, h, id = box_id
        # To show counting numbers on the top of an object
        cv2.putText(roi, str(id), (x, y - 15), cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 2)
        cv2.rectangle(roi, (x, y), (x + w, y + h), (0, 255, 0), 3)

    cv2.imshow("roi", roi)
    cv2.imshow("Frame", frame)
    cv2.imshow("Mask", mask)

   # key = cv2.waitKey(30)
    if cv2.waitKey(100) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()